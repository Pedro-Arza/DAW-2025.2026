package com.demo.minitienda;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
// La anotación @SpringBootApplication inicia la aplicación Spring Boot
@SpringBootApplication
public class MinitiendaApplication {
public static void main(String[] args) {
// Método para iniciar la aplicación Spring Boot
SpringApplication.run(MinitiendaApplication.class, args);
}
}